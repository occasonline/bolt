
    import React, { useState } from 'react';
    import axios from 'axios';
    import { saveAs } from 'file-saver';
    import jsPDF from 'jspdf';
    import 'jspdf-autotable';

    function App() {
      const [email, setEmail] = useState('');
      const [password, setPassword] = useState('');
      const [token, setToken] = useState('');
      const [generatedContent, setGeneratedContent] = useState('');
      const [customContent, setCustomContent] = useState('');

      const register = async () => {
        await axios.post('/api/register', { email, password });
        alert('Registered successfully');
      };

      const login = async () => {
        const response = await axios.post('/api/login', { email, password });
        setToken(response.data.token);
        alert('Logged in successfully');
      };

      const generateContent = async () => {
        const response = await axios.post('/api/generate', { name: 'John Doe', skills: 'Python, React', experience: '3 years' }, {
          headers: { Authorization: `Bearer ${token}` }
        });
        setGeneratedContent(response.data.content);
        setCustomContent(response.data.content);
      };

      const exportToPDF = () => {
        const doc = new jsPDF();
        doc.text("AI Résumé Booster", 20, 10);
        doc.autoTable({ startY: 20, html: '#content-table' });
        doc.save('resume.pdf');
      };

      const exportToWord = () => {
        const blob = new Blob([customContent], { type: 'application/msword' });
        saveAs(blob, 'resume.doc');
      };

      return (
        <div>
          <h1>AI Résumé Booster</h1>
          <input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
          <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
          <button onClick={register}>Register</button>
          <button onClick={login}>Login</button>
          <button onClick={generateContent}>Generate Resume</button>
          <div>
            <h2>Generated Content</h2>
            <textarea value={customContent} onChange={(e) => setCustomContent(e.target.value)} rows="10" cols="50" />
            <button onClick={exportToPDF}>Export to PDF</button>
            <button onClick={exportToWord}>Export to Word</button>
          </div>
        </div>
      );
    }

    export default App;
  </boltAction