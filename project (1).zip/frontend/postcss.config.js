
    export default {
      plugins: {
        tail